import { Component } from '@angular/core';

@Component({
  selector: 'app-oftalmologia',
  templateUrl: './oftalmologia.component.html',
  styleUrls: ['./oftalmologia.component.scss']
})
export class OftalmologiaComponent {

}
