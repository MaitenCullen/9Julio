import { Component } from '@angular/core';

@Component({
  selector: 'app-cardiologia',
  templateUrl: './cardiologia.component.html',
  styleUrls: ['./cardiologia.component.scss']
})
export class CardiologiaComponent {

}
