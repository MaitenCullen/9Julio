import { Component } from '@angular/core';

@Component({
  selector: 'app-audiologia',
  templateUrl: './audiologia.component.html',
  styleUrls: ['./audiologia.component.scss']
})
export class AudiologiaComponent {

}
