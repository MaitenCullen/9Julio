import { Component } from '@angular/core';

@Component({
  selector: 'app-radiologia',
  templateUrl: './radiologia.component.html',
  styleUrls: ['./radiologia.component.scss']
})
export class RadiologiaComponent {

}
