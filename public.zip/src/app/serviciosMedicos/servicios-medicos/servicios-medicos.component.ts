import { Component } from '@angular/core';

@Component({
  selector: 'app-servicios-medicos',
  templateUrl: './servicios-medicos.component.html',
  styleUrls: ['./servicios-medicos.component.scss']
})
export class ServiciosMedicosComponent {

}
