import { Component } from '@angular/core';

@Component({
  selector: 'app-servicios-ecografia',
  templateUrl: './servicios-ecografia.component.html',
  styleUrls: ['./servicios-ecografia.component.scss']
})
export class ServiciosEcografiaComponent {

}
