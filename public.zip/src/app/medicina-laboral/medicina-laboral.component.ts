import { Component } from '@angular/core';

@Component({
  selector: 'app-medicina-laboral',
  templateUrl: './medicina-laboral.component.html',
  styleUrls: ['./medicina-laboral.component.scss']
})
export class MedicinaLaboralComponent {

}
