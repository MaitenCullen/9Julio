import { Component } from '@angular/core';

@Component({
  selector: 'app-servicios-base',
  templateUrl: './servicios-base.component.html',
  styleUrls: ['./servicios-base.component.scss']
})
export class ServiciosBaseComponent {

}
